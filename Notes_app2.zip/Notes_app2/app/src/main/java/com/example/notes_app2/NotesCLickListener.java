package com.example.notes_app2;

import androidx.cardview.widget.CardView;

import com.example.notes_app2.Models.Notes;

public interface NotesCLickListener
{
    void OnOnclick(Notes notes);
    void onLongClick(Notes notes, CardView cardview);


    void onClick(Notes notes);
}
